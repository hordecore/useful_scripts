#!/bin/bash

. reductor.conf

iconv -f cp1251 -t koi8-r "${1:-dump.xml}"  | sed -e 's/\[/url>\n/g; s/\]\]/\n\]\]/g' | grep http | tail -n +2 | sed -e 's/http:\/\/www\./http:\/\//g' | grep -v '^https://'
