#!/bin/bash

. reductor.conf

activate() {
	read cpuid regstate url_count pkt_total pkt_match <<< "$(</proc/net/ipt_reductor/block_list)"
	act_code=${RED_REG_ACTCODE//-/}
	echo unlock_$act_code > /proc/net/ipt_reductor/block_list
}

activate
