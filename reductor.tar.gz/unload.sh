#!/bin/bash

FUNCTIONS=0
[ -f /etc/init.d/functions ] && FUNCTIONS=1 && . /etc/init.d/functions

iptables --line -nvL OUTPUT | grep -w "reductor" | tac | while read num tmp; do
	iptables -D OUTPUT "$num"
done

iptables --line -nvL FORWARD | grep -w "reductor" | tac | while read num tmp; do
	iptables -D FORWARD "$num"
done

iptables --line -t mangle -nvL PREROUTING | grep -w "reductor" | tac | while read num tmp; do
	iptables -t mangle -D PREROUTING "$num"
done

if [ $FUNCTIONS = 1 ]; then
	rmmod ipt_reductor && echo_success || echo_failure
else
	rmmod ipt_reductor && echo "Module removed" || echo "Cant remove module"
fi
echo
