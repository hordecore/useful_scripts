#!/bin/bash

mount -o rw,remount /mnt/ro_disc
chattr -i /etc/lilo.conf
ln -s /mnt/ro_disc/boot/ /boot
chattr -i -R /mnt/ro_disc/boot/
cp bzImage /boot/100hz
lilo

