#!/bin/bash

./unload.sh
insmod ipt_reductor.o
./activate.sh
./load.db.sh

# chroot . /bin/iptables -t mangle -I PREROUTING -p tcp --dport 80 -m reductor --string "reductor" -j REJECT --reject-with tcp-reset
chroot . /bin/iptables -t filter -I FORWARD -p tcp --dport 80 -m reductor --string "reductor" -j REJECT --reject-with tcp-reset
dmesg -c
