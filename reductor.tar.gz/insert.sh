#!/bin/bash

if lsmod | grep -q ipt_reductor; then
	./unload.sh
fi

insmod ipt_reductor.o

./dumper.sh > formatted_list.txt

while read url; do
	echo "$url" > /proc/net/ipt_reductor/block_list
done < formatted_list.txt

rm -f formatted_list.txt

chroot . /bin/iptables -I FORWARD -p tcp --dport 80 -m reductor --string "all forbidden sites" -j DROP
